#src/Memory/Retrieval.py

from typing import List, Optional, Dict, Any
import os
import faiss
import numpy as np
from src.Memory.MemoryItem import MemoryItem
from src.Engine.EmbeddingModel import EmbeddingModel
from src.Engine.RerankerModel import Reranker
from src.Memory.DatabaseManager import DBManager
from src.Utils.logger import get_logger


logger = get_logger("[RETRIEVAL]")


class Retrieval:

    def __init__(
        self,
        EmbeddingModel: EmbeddingModel,
        Reranker: Reranker,
        DataBase: DBManager,
        index_path: str = "vectors.faiss"
    ) -> None:

        self.EmbeddingModel = EmbeddingModel
        self.Reranker = Reranker
        self.db = DataBase
        self.dimension = self.EmbeddingModel.dimension
        self.index_path = index_path
        self.index = self._create_empty_index()
        self._load_or_build_index()

    def _create_empty_index(self):

        return faiss.IndexIDMap2(
            faiss.IndexFlatIP(self.dimension)
        )

    def _load_or_build_index(self):

        if not os.path.exists(self.index_path):
            self._build_index()
            return

        try:

            logger.info(
                f"Loading FAISS index: {self.index_path}"
            )

            loaded_index = faiss.read_index(
                self.index_path
            )

            if loaded_index.d != self.dimension:

                logger.warning(
                    "FAISS dimension mismatch. Rebuilding index."
                )

                self._build_index()
                return

            self.index = loaded_index

            logger.info(
                f"FAISS loaded successfully. "
                f"Vectors: {self.index.ntotal}"
            )

        except Exception as e:

            logger.error(
                f"Failed to load FAISS index: {e}"
            )

            self._build_index()

    def _build_index(self):

        logger.info(
            "Building FAISS index from database..."
        )

        try:

            records = self.db.get_all_embeddings()

            if not records:

                self.index = self._create_empty_index()
                return

            ids = []
            embeddings = []

            for memory_id, embedding in records:

                if embedding is None:
                    continue

                embedding = np.asarray(
                    embedding,
                    dtype=np.float32
                ).reshape(1, -1)

                if embedding.shape[1] != self.dimension:

                    logger.warning(
                        f"Skipping ID {memory_id}: "
                        f"wrong embedding dimension."
                    )

                    continue

                ids.append(int(memory_id))
                embeddings.append(embedding[0])

            if not embeddings:

                self.index = self._create_empty_index()
                return

            embeddings = np.asarray(
                embeddings,
                dtype=np.float32
            )

            ids = np.asarray(
                ids,
                dtype=np.int64
            )

            self.index = self._create_empty_index()

            self.index.add_with_ids(
                embeddings,
                ids
            )

            if not self._save_index():
                raise RuntimeError(
                    "Failed to save rebuilt FAISS index."
                )

            logger.info(
                f"FAISS index built. "
                f"Vectors: {self.index.ntotal}"
            )

        except Exception as e:

            logger.error(
                f"Failed to build FAISS index: {e}"
            )

            raise

    def _save_index(self):

        try:

            directory = os.path.dirname(
                self.index_path
            )

            if directory:
                os.makedirs(
                    directory,
                    exist_ok=True
                )

            faiss.write_index(
                self.index,
                self.index_path
            )

            return True

        except Exception as e:

            logger.error(
                f"Failed to save FAISS index: {e}"
            )

            return False

    def _validate_embedding(
        self,
        embedding: np.ndarray
    ) -> np.ndarray:

        embedding = np.asarray(
            embedding,
            dtype=np.float32
        ).reshape(1, -1)

        if embedding.shape[1] != self.dimension:

            raise ValueError(
                f"Invalid embedding dimension: "
                f"{embedding.shape[1]} "
                f"(expected {self.dimension})"
            )

        return embedding

    def add(
        self,
        memory_id: int,
        embedding: np.ndarray
    ) -> bool:

        if embedding is None:

            logger.warning(
                f"Cannot add memory {memory_id}: "
                f"embedding is None."
            )

            return False

        try:

            embedding = self._validate_embedding(
                embedding
            )

            memory_id_array = np.asarray(
                [int(memory_id)],
                dtype=np.int64
            )

            self.index.remove_ids(
                memory_id_array
            )

            self.index.add_with_ids(
                embedding,
                memory_id_array
            )

            if not self._save_index():

                self.index.remove_ids(
                    memory_id_array
                )

                return False

            return True

        except Exception as e:

            logger.error(
                f"Failed to add memory "
                f"{memory_id}: {e}"
            )

            return False

    def remove(
        self,
        memory_id: int
    ) -> bool:

        try:

            removed = self.index.remove_ids(
                np.asarray(
                    [int(memory_id)],
                    dtype=np.int64
                )
            )

            if not self._save_index():
                return False

            return bool(removed > 0)

        except Exception as e:

            logger.error(
                f"Failed to remove memory "
                f"{memory_id} from FAISS: {e}"
            )

            return False

    def _dense_search(
        self,
        query_embedding: np.ndarray,
        limit: int = 100
    ) -> List[Dict[str, Any]]:

        if self.index.ntotal == 0 or limit <= 0:
            return []

        query_embedding = self._validate_embedding(
            query_embedding
        )

        limit = min(
            int(limit),
            self.index.ntotal
        )

        distances, ids = self.index.search(
            query_embedding,
            limit
        )

        results = []

        for rank, (memory_id, distance) in enumerate(
            zip(ids[0], distances[0]),
            start=1
        ):

            if memory_id == -1:
                continue

            results.append({
                "id": int(memory_id),
                "rank": rank,
                "distance": float(distance)
            })

        return results

    def get_nearest_memory(
        self,
        query: str
    ) -> Optional[Dict[str, Any]]:

        if not query or not query.strip():
            return None

        if self.index.ntotal == 0:
            return None

        query_embedding = self.EmbeddingModel.encode(
            f"query: {query}"
        )

        query_embedding = self._validate_embedding(
            query_embedding
        )

        distances, indices = self.index.search(
            query_embedding,
            1
        )

        memory_id = int(indices[0][0])

        if memory_id == -1:
            return None

        return {
            "id": memory_id,
            "similarity": float(distances[0][0])
        }

    def _compute_rrf(
        self,
        bm25_results: List[MemoryItem],
        dense_results: List[Dict[str, Any]],
        k_rrf: int = 60,
        limit: int = 20
    ) -> List[Dict[str, Any]]:

        if limit <= 0:
            return []

        merged = {}

        for rank, item in enumerate(
            bm25_results,
            start=1
        ):

            merged[item.id] = {
                "item": item,
                "rrf_score": 1.0 / (k_rrf + rank),
                "bm25_rank": rank,
                "embedding_rank": None,
                "embedding_distance": None
            }

        dense_only = []

        for result in dense_results:

            memory_id = result["id"]

            dense_score = 1.0 / (
                k_rrf + result["rank"]
            )

            if memory_id in merged:

                merged[memory_id]["rrf_score"] += dense_score
                merged[memory_id]["embedding_rank"] = result["rank"]
                merged[memory_id]["embedding_distance"] = result["distance"]

            else:

                dense_only.append(result)

        if dense_only:

            ids = [
                result["id"]
                for result in dense_only
            ]

            items = self.db.get_by_ids(ids)

            items_by_id = {
                item.id: item
                for item in items
            }

            for result in dense_only:

                memory_id = result["id"]
                item = items_by_id.get(memory_id)

                if item is None:
                    continue

                merged[memory_id] = {
                    "item": item,
                    "rrf_score": 1.0 / (
                        k_rrf + result["rank"]
                    ),
                    "bm25_rank": None,
                    "embedding_rank": result["rank"],
                    "embedding_distance": result["distance"]
                }

        ranked = sorted(
            merged.values(),
            key=lambda x: x["rrf_score"],
            reverse=True
        )

        return ranked[:limit]

    def Retrieve(
        self,
        query: str,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:

        if not query or not query.strip():
            return []

        if top_k <= 0:
            return []

        query_embedding = self.EmbeddingModel.encode(
            f"query: {query}"
        )

        bm25_results = self.db.search_fts(
            query,
            limit=100
        )

        dense_results = self._dense_search(
            query_embedding,
            limit=100
        )

        if not bm25_results and not dense_results:
            return []

        rrf_results = self._compute_rrf(
            bm25_results,
            dense_results,
            k_rrf=60,
            limit=20
        )

        if not rrf_results:
            return []

        documents = [
            result["item"].value
            for result in rrf_results
        ]

        reranker_scores = self.Reranker.rank(
            query=query,
            documents=documents
        )

        if len(reranker_scores) != len(rrf_results):

            raise RuntimeError(
                "Reranker returned an invalid "
                "number of scores."
            )

        for result, score in zip(
            rrf_results,
            reranker_scores
        ):

            result["reranker_score"] = float(score)

        rrf_results.sort(
            key=lambda x: x["reranker_score"],
            reverse=True
        )

        return rrf_results[:top_k]